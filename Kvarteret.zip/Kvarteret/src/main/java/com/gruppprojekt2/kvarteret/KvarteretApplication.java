package com.gruppprojekt2.kvarteret;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KvarteretApplication {

	public static void main(String[] args) {
		SpringApplication.run(KvarteretApplication.class, args);
	}

}
