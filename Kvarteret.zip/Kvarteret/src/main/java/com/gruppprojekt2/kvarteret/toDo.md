**To fix**
- logga ut knapp✓
- tillbaka knapp✓
- unit test ✓
- lägga upp annonser knapp✓
- sida/template lägga till annonser✓
- nyaste annonsen/Id ***
- Css till alla templates

font - 
färg - 


CSS

itemS - Vincent

addItem - Yassaman
item - Ulf
newUser - Rebecca


/*
#0C4767 mörkblå
#88AB75 aspargus /grön
#FFC09F peach
#669BBC ljusblå


Bahnschrift SemiBold - rubrik
Bahnschrift Light - brödtext
Bahnschrift Light SemiCondensed - preivous knappar


*/